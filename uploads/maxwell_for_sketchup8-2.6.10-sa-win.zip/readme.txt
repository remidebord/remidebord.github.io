+------------------------------------------------------------------------------------------------
| Build Information
+------------------------------------------------------------------------------------------------

  Product: Maxwell for SketchUp (Standalone)
  Version: 2.6.10

+------------------------------------------------------------------------------------------------
| Compatibility
+------------------------------------------------------------------------------------------------

  The files contained in this distribution support:

    - Google SketchUp and SketchUp Pro, versions 6+
    - Microsoft Windows XP+, 32-bit or 64-bit

+------------------------------------------------------------------------------------------------
| Note
+------------------------------------------------------------------------------------------------
 
  If this version of the Maxwell for SketchUp Render Suite plugin is currently installed, it 
  will be necessary to use Programs and Features (Add and Remove Programs on XP) to uninstall 
  it before installing this plugin. 
  
+------------------------------------------------------------------------------------------------
| Installation
+------------------------------------------------------------------------------------------------
  
  Please note that some un-zip software may alter the folder-structure of the downloaded zip 
  file. This will cause failures, so make sure the structure is as follows:

    + Maxwell_for_SketchUp8-2.6.10-sa-win
      - readme.txt 
      + setup
        - setup.exe 
        - Maxwell.SketchUp8.Standalone.Installer.msi
        + vcredist_x86
          - vcredist_x86.exe 

  Installation is accomplished using the following steps:

    1. Unzip the downloaded .zip in a location where you possess rights to install software.
  
    2. Navigate to the /setup subfolder, right-click on setup.exe, and choose Run as administrator. 
  
    3. The installer allows you to specify the directory into which files will be written. 
       The directory path specified here should be your SketchUp directory, typically:
      
         C:\Program Files (x86)\Google\Google SketchUp 8 
     
    4. Once installed, the plugin should automatically appear in SketchUp; if you do not 
       see a new Maxwell item in your Plugins menu, go to SketchUp's Preferences > Extensions 
       window and make sure the Maxwell for SketchUp extension is enabled.

  Note that the plugin's installer is not capable of uninstalling some very old versions of the
  Maxwell for SketchUp plugin. If you have any doubt about whether one of these might be installed, 
  use Windows Programs and Features (Add or Remove Programs in XP) to verify that you do not find 
  any entries named similar to MaxwellExport (Version 2.x). 

  If such a plugin is indeed currently installed, you should also find a MaxwellExport.dll (actual 
  name may vary slightly) in your SketchUp Extensions directory. If not removed, this will cause 
  the new plugin to malfunction; for example, it may start two instances of Maxwell Render when 
  rendering, or one, when attempting to write an MXS file or render in Maxwell Fire. If you find 
  that any of the above things are true, it will be necessary to remove the old plugin components:

    1. Use Windows Programs and Features to uninstall the old plugin.

    2. Delete any Maxwell-related .dll files from [SketchUp 8]\Extensions.

    3. Delete any Maxwell-related files and folders from [SketchUp 8]\Plugins.

    4. Use Windows Programs and Features to Repair the new plugin.

+------------------------------------------------------------------------------------------------
| Prerequisites - Microsoft Silverlight 3.0 or 4.0
+------------------------------------------------------------------------------------------------

  This plugin uses Microsoft Silverlight to implement its user-interface.
 
  If you do not currently have Microsoft Silverlight version 3.0 or 4.0 installed on your 
  machine, you will be prompted to download and install it when you attempt to use the plugin's 
  user interface.
  
  If you have Silverlight 5.0 installed, the plugin may not run correctly, and you will be 
  prompted to uninstall it and install Silverlight 4.0. Silverlight 4.0 may be obtained
  by opening Internet Explorer (on Windows) or Safari (on Mac OSX) and navigating to this url:
  
    http://go.microsoft.com/fwlink/?LinkID=149156&v=4.0.60310.0
  
  After installing Microsoft Silverlight 4.0, it will be necessary to restart SketchUp.

+------------------------------------------------------------------------------------------------
| Prerequisites - Microsoft Visual C++ 2008 SP1 Runtime
+------------------------------------------------------------------------------------------------

  This plugin uses the Microsoft Visual C++ 2008 SP1 Runtime; if it is not installed, the
  plugin will fail to load. The main installer file, setup.exe, checks whether it is necessary
  to install the runtime, and if so, installs it automatically. However, should the plugin fail
  to load, it is recommended to try performing installation of this runtime manually:

    1. In the unzipped download, locate the vcredist_x86 folder.
  
    2. Right-click vcredist_x86.exe and choose Run as administrator.

+------------------------------------------------------------------------------------------------
| Credits
+------------------------------------------------------------------------------------------------

  This plugin uses the picojson JSON parser from Cybozu Labs, Inc.

  /* Copyright 2009 Cybozu Labs, Inc.
  * 
  * Redistribution and use in source and binary forms, with or without
  * modification, are permitted provided that the following conditions are met:
  * 
  * 1. Redistributions of source code must retain the above copyright notice,
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 
  * THIS SOFTWARE IS PROVIDED BY CYBOZU LABS, INC. ``AS IS'' AND ANY EXPRESS OR
  * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
  * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
  * EVENT SHALL CYBOZU LABS, INC. OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
  * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  * 
  * The views and conclusions contained in the software and documentation are
  * those of the authors and should not be interpreted as representing official
  * policies, either expressed or implied, of Cybozu Labs, Inc.
  *
  */
